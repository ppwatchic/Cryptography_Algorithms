import java.security.*;
import java.math.BigInteger;
import java.nio.charset.StandardCharsets;

import java.security.interfaces.RSAPrivateKey;
import java.security.interfaces.RSAPublicKey;

import javax.crypto.Cipher;

public class RSAPerformance {
	static final String TAG = "AsymmetricAlgorithmRSA: ";
	static JCERSAPublicKey rsakey;
    static JCERSAPrivateKey rsaprikey;
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// Generate key pair for 1024-bit RSA encryption and decryption		
		String theTestText = "96385274185236985214785236985214";
		
        Key publicKey = null;
        Key privateKey = null;
        String puk = "";
        String prk = "";
        String stre = "";
        String strm = "";
        try {
            KeyPairGenerator kpg = KeyPairGenerator.getInstance("RSA");
            kpg.initialize(1024);
            KeyPair kp = kpg.genKeyPair();
            publicKey = kp.getPublic();
            privateKey = kp.getPrivate();

            System.out.println(TAG + " Length of plaintext is: " + theTestText.length());

            // extract and display public_key pair .
            rsakey = new JCERSAPublicKey((RSAPublicKey)publicKey);
            BigInteger e = rsakey.getPublicExponent();
            BigInteger m = rsakey.getModulus();
            stre = e.toString();
            System.out.println(TAG + " PU Exponent is: " + stre);
            strm = m.toString();
            System.out.println(TAG + " PU Modulus is: " + strm + "\n And the length is: " + strm.length());
            // extract and display private_key pair

            rsaprikey = new JCERSAPrivateKey((RSAPrivateKey)privateKey);
            e = rsaprikey.getPrivateExponent();
            m = rsaprikey.getModulus();
            stre = e.toString();
            System.out.println(TAG + " PR Exponent is: " + stre);
            strm = m.toString();
            System.out.println(TAG + " PR Modulus is: " + strm);


            // track the detail about the publicKey&privateKey
            byte[] pukbytes = publicKey.getEncoded();
            byte[] prkbytes = privateKey.getEncoded();

            // Display the standard algorithm name for this key
            //System.out.println(TAG + " " + publicKey.getAlgorithm());
            //System.out.println(TAG + " " + publicKey.getFormat());

            // Create a BigInteger using the byte array
            BigInteger bipuk = new BigInteger(pukbytes);
            BigInteger biprk = new BigInteger(prkbytes);

            /*
            puk = bipuk.toString();
            prk = biprk.toString();
            System.out.println(TAG + " publicKey Pair: " + puk);
            System.out.println(TAG + " privateKey Pair: " + prk);
            */
        } catch (Exception e) {
        	System.out.println(TAG + "RSA key pair error");
        }
        System.out.println();
        // Encode the original data with RSA private key
        byte[] encodedBytes = null;
        try {
            Cipher c = Cipher.getInstance("RSA");
            c.init(Cipher.ENCRYPT_MODE, publicKey);
            long startTime = System.nanoTime();         // System.currentTimeMillis();
            encodedBytes = c.doFinal(theTestText.getBytes());
            long endTime = System.nanoTime();           // System.currentTimeMillis();
            System.out.println(TAG + " It took " + (endTime-startTime) + " nanoseconds to do Encryption (using public key pair)");
        } catch (Exception e) {
        	System.out.println(TAG + " RSA encryption error");
        }
        
        System.out.println();
     // Decode the encoded data with RSA public key
        byte[] decodedBytes = null;
        String str;
        try {
            Cipher c = Cipher.getInstance("RSA");
            c.init(Cipher.DECRYPT_MODE, privateKey);
            long startTime = System.nanoTime();         // System.currentTimeMillis();
            decodedBytes = c.doFinal(encodedBytes);
            long endTime = System.nanoTime();           // System.currentTimeMillis();
            System.out.println(TAG + " It took " + (endTime-startTime) + " nanoseconds to do Decryption (using private key pair)");

            // convert byte[] to string
            str = new String(decodedBytes, StandardCharsets.UTF_8);
            System.out.println(TAG + " Ubuntu Test output: " + str);
        } catch (Exception e) {
        	System.out.println(TAG + " RSA decryption error");
        }

	}

}
